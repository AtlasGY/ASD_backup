git clone https://github.com/brendenlake/omniglot.git
unzip omniglot/python/images_background.zip -d omniglot/python
unzip omniglot/python/images_evaluation.zip -d omniglot/python
