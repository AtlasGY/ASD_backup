from setuptools import setup

setup(  name='dcase2022_task2',
        version='1.0',
        description='DCASE 2022 Challenge Task 2',
        author='Antonio Almudevar',
        author_email='almudevar@unizar.es',
        packages=['dcase2022_task2'],
    )