# DCASE 2022 - Task 2

